# Graph Matching Honours Project

This is the code repository for my Honours project on graph matching.

**The problem is:** Given two graphs G1 and G2, a query subgraph g1 from G1, find top-k matching subgraphs of G2 for g1.