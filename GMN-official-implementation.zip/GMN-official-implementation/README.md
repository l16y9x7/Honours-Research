# DeepMind Research

This repository contains implementations and illustrative code to accompany
DeepMind publications. Along with publishing papers to accompany research
conducted at DeepMind, we release open-source
[environments](https://deepmind.com/research/open-source/open-source-environments/),
[data sets](https://deepmind.com/research/open-source/open-source-datasets/),
and [code](https://deepmind.com/research/open-source/open-source-code/) to
enable the broader research community to engage with our work and build upon it,
with the ultimate goal of accelerating scientific progress to benefit society.
For example, you can build on our implementations of the
[Deep Q-Network](https://github.com/deepmind/dqn) or
[Differential Neural Computer](https://github.com/deepmind/dnc), or experiment
in the same environments we use for our research, such as
[DeepMind Lab](https://github.com/deepmind/lab) or
[StarCraft II](https://github.com/deepmind/pysc2).

If you enjoy building tools, environments, software libraries, and other
infrastructure of the kind listed below, you can view open positions to work in
related areas on our [careers page](https://deepmind.com/careers/).

For a full list of our publications, please see
https://deepmind.com/research/publications/

## Projects

*   [PrediNet Architecture and Relations Game Datasets](PrediNet)
*   [Unsupervised Adversarial Training](unsupervised_adversarial_training)
*   [Graph Matching Networks for Learning the Similarity of Graph Structured
    Objects](graph_matching_networks), ICML 2019
*   [REGAL: Transfer Learning for Fast Optimization of Computation Graphs](regal)

## Disclaimer

*This is not an official Google product.*
