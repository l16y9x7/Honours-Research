import pandas as pd
import numpy as np
import random as r

data = pd.read_csv('../Dataset/cora/cora.content',sep="\t",header=None)
cites = pd.read_csv('../Dataset/cora/cora.cites',sep="\t",header=None)

labels = pd.get_dummies(data[data.shape[1]-1])   # change the label from text into one-hot encoding
labels = np.array(labels)
labels = list(map(lambda x: np.argwhere(x==1)[0][0],labels))   # list of labels represented by number 0 - 6
labels = dict(zip([i for i in range(data.shape[0])], labels))
labels_dict = {0:set({}),1:set({}),2:set({}),3:set({}),4:set({}),5:set({}),6:set({})}   # map type to the cooresponding list of papers
reverse_label_dict={}    # map paper to type
for (i,j) in labels.items():
    labels_dict[j].add(i)
    reverse_label_dict[i] = j

#change the orignal paper index in the dataset to natural numbers starting from 0
original_index = list(data[0])
new_index = [i for i in range(data.shape[0])]
ref = dict(zip(original_index,new_index))         # store which index is changed to which
data[0] = new_index
graph = np.array(data)[:,1:-1]                     # take the feature matrix

citation = {}
# Here, for convenience, we relax the edges to undirected(as long as the two papers are related)
for i in range(cites.shape[0]):
    if ref[cites.iloc[i][0]] not in citation:
        citation[ref[cites.iloc[i][0]]] = {ref[cites.iloc[i][1]]}
    else:
        citation[ref[cites.iloc[i][0]]].add(ref[cites.iloc[i][1]])
    if ref[cites.iloc[i][1]] not in citation:
        citation[ref[cites.iloc[i][1]]] = {ref[cites.iloc[i][0]]}
    else:
        citation[ref[cites.iloc[i][1]]].add(ref[cites.iloc[i][0]])

# Classify the nodes by their label
# paper_genre = {}
# for i in range(len(labels)):


def random_subgraph(graph, citation, n):
    # generate random connected subgraph from the dataset with n nodes.
    m = n
    starting_point = r.randint(0,graph.shape[0]-1)
    result = [starting_point]
    if starting_point in citation:
        neighbours = citation[starting_point]
    while n > 1:
        if not neighbours:
            return random_subgraph(graph,citation,m)
        point = r.sample(neighbours,1)[0]
        neighbours.remove(point)
        if point not in result:
            result.append(point)
            if point in citation:
                for p in citation[point]:
                    neighbours.add(p)
            n -= 1
    return result


def is_connected(nodes, citation):
    # check if the nodes form a connected graph
    neighbours = set({})
    for i in nodes:
        neighbours = neighbours.union(citation[i])
    common = set(nodes).intersection(neighbours)
    return len(common) == len(nodes)


def connectivity_check(candidate, query, citation):
    # check if the two graphs have the same structure
    for i in range(len(candidate)):
        for j in range(i + 1, len(candidate)):
            if candidate[j] in citation[candidate[i]]:
                if query[j] not in citation[query[i]]:
                    return False
    return True


def match(query, graph, citation, labels_dict, reverse_label_dict, feature):
    # input: query subgraph, the big graph, citation(connectivity), match based on feature or not
    # return a matching subgraph in the big graph
    query_size = len(query)
    labels = [reverse_label_dict[i] for i in query]  # label of nodes of the query subgraph
    labels_count = {}
    for i in labels:
        if i in labels_count:
            labels_count[i] += 1
        else:
            labels_count[i] = 1

    # 1. matched based on labels and features, for the query subgraph, we find subgraph g in graph such that the labels are the
    # same and the difference in feature vectors is minimum. Use a greedy/BFS approach.
    if feature:
        ranking = {}  # ranking of similarity in feature vector for all nodes with the same label for each query node
        for i in range(len(query)):
            candidates = []
            for j in labels_dict[reverse_label_dict[query[i]]]:
                if j not in query:
                    candidates.append((sum(abs(graph[query[i]] - graph[j])), j))
            candidates.sort()
            ranking[i] = [k for j, k in candidates][:100]  # Prune the worse ones to reduce computation
        counter = [0] * len(query)
        ranges = [len(ranking[i]) - 1 for i in ranking]  # range of index
        while True:
            candidate = [ranking[i][counter[i]] for i in range(len(query))]
            if is_connected(candidate, citation):
                return candidate
            else:
                counter[-1] += 1
                if counter[-1] >= ranges[-1]:
                    for i in range(len(counter)):
                        if counter[len(counter) - i - 1] >= ranges[len(counter) - i - 1]:
                            if i == len(counter) - 1:
                                return []
                            counter[len(counter) - i - 1] = 0
                        else:
                            counter[len(counter) - i - 1] += 1
                            break

                            # 2. matched based on the structure and labels, for the query subgraph, we find subgraph g in graph such that the labels
    # are the same and the structural difference is the minimum.(by comparing the connectivity)
    else:
        edge = {}  # record the edges between the query node and other query nodes
        for i in range(len(query)):
            edge[i] = {}
        for i in range(len(query)):
            for j in range(i + 1, len(query)):
                if query[i] in citation[query[j]]:
                    if reverse_label_dict[query[j]] in edge[i]:
                        edge[i][reverse_label_dict[query[j]]] += 1
                    else:
                        edge[i][reverse_label_dict[query[j]]] = 1
                    if reverse_label_dict[query[i]] in edge[j]:
                        edge[j][reverse_label_dict[query[i]]] += 1
                    else:
                        edge[j][reverse_label_dict[query[i]]] = 1
        candidates = {}  # candidate matching nodes for each query node based on adjacency
        for i in range(len(query)):
            candidates[i] = [j for j in labels_dict[reverse_label_dict[query[i]]] if j not in query]

        real_candidates = {}  # candidates matching the structure in the subgraph
        for i in range(len(query)):
            for j in candidates[i]:
                edge_copy = edge[i].copy()
                adj = citation[j]
                for k in adj:
                    if reverse_label_dict[k] in edge_copy:
                        edge_copy[reverse_label_dict[k]] -= 1
                        if sum(list(edge_copy.values())) == 0:
                            if i not in real_candidates:
                                real_candidates[i] = [j]
                            else:
                                real_candidates[i].append(j)
            if i not in real_candidates:
                return []
        counter = [0] * len(query)
        ranges = [len(real_candidates[i]) - 1 for i in real_candidates]  # range of index
        while True:
            candidate = [real_candidates[i][counter[i]] for i in range(len(query))]
            if is_connected(candidate, citation) and connectivity_check(candidate, query, citation):
                return candidate
            else:
                counter[-1] += 1
                if counter[-1] >= ranges[-1]:
                    for i in range(len(counter)):
                        if counter[len(counter) - i - 1] >= ranges[len(counter) - i - 1]:
                            if i == len(counter) - 1:
                                return []
                            counter[len(counter) - i - 1] = 0
                        else:
                            counter[len(counter) - i - 1] += 1
                            break

def pair_generation(n, f_size, s_size):
    feature_pairs = []
    structure_pairs = []
    # generate n pairs of matching subgraphs of size f_size and s_size respectively for each feature and structure
    for i in range(n):
        result = []
        while not result:
            g = random_subgraph(graph,citation, f_size)
            result = match(g, graph, citation, labels_dict, reverse_label_dict, True)
        print(i+1, " pairs of f generated")
        feature_pairs.append((g,result))
        result = []
        while not result:
            g = random_subgraph(graph,citation, s_size)
            result = match(g, graph, citation, labels_dict, reverse_label_dict, False)
        print(i+1, " pairs of s generated")
        structure_pairs.append((g,result))
    return feature_pairs, structure_pairs





