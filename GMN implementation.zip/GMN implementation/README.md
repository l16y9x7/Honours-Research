# Graph Matching Network Implementation

This is an implementation of the paper Graph Matching Network for Learning the Similarity of Graph Structured Objects. <br />
**hmatch4py is an external library available at https://github.com/Jacobe2169/GMatch4py** <br />
**graph_matching_network_deepmind_official is the official release of the implementation of the GMN model available at https://github.com/deepmind/deepmind-research** <br />