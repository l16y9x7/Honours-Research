# -*- coding: utf-8 -*-

"""This file implements the graph generator for the problem. It is used to generate data for training, validation and testing.
It's the same as in the notebook file and its purpose is to ease the import process.
"""

import networkx as nx
import numpy as np
import random as r


def generate_pair_of_matching_graphs_for_nodes(current_G1, current_G2, num_nodes, node_attrs, edge_attrs, wn=1,
                                               density=0.5):
    """Inputs: current_G1, current_G2: current G1 and G2 graphs, the new graph is added to the current ones
               n - number of pairs of graphs to be generated
               num_nodes - number of nodes in a graph
               node_attrs - a dict of node attributes as stringsand their domains,
                            the exact values of attributes are randomly generated
               edge_attrs - a dict of edge attributes as strings and their domains,
                            the exact values of attributes are randomly generated
               wn - a parameter in [0,1] determining the significance in node similarity in generating the pairs, 1 if only node
                    attributes are considered(i.e. all nodes are the same, otherwise, each node has wn probability to change its
                    attributes)
               density - a parameter in [0,1] decides how dense the graph should be, on the premise that the graph is connected,
                         1 is fully connected and 0 is a spanning tree. A number between is the probability that an edge is added
                         between two nodes. The spanning tree is randomly generated.
       Return: one pair of matching graphs
       Strategy: If focusing on nodes, generate one graph first, use the nodes to generate a matching graph by randomly
                    connecting.
                 """

    g1 = nx.Graph()
    g2 = nx.Graph()

    if current_G1.nodes:
        n1 = r.sample(current_G1.nodes.data(),
                      1)  # select a point of overlapping for the current graph and the new pair
        g1.add_nodes_from(n1)

    ################################# 1. when focusing on nodes
    # generate random nodes
    if len(g1.nodes) > 0:  # no. of new nodes to be generated
        ni = num_nodes - 1
    else:
        ni = num_nodes
    for i in range(len(current_G1.nodes), len(current_G1.nodes) + ni):
        g1.add_node(i)
        for attr in node_attrs:
            g1.nodes[i][str(attr)] = r.choice(node_attrs[attr])

    g2.add_nodes_from(g1.nodes.data())
    for i in g2.nodes:
        for attr in node_attrs:
            if wn < r.uniform(0, 1):
                g2.nodes[i][str(attr)] = r.choice(node_attrs[attr])

    connected_nodes = {list(g1.nodes)[0]}  # record currently connected nodes
    connected_nodes2 = {list(g2.nodes)[0]}  # record currently connected nodes
    # connect the nodes for g1
    while len(connected_nodes) < num_nodes:
        i = r.sample(connected_nodes, 1)[0]
        choices = [j for j in list(g1.nodes) if j not in connected_nodes]
        if not choices:
            continue
        c = r.choice(choices)
        g1.add_edge(i, c)
        for attr in edge_attrs:
            g1.edges[i, c][str(attr)] = r.choice(edge_attrs[attr])
        connected_nodes.add(c)

    # add edges using density for g1
    for i in g1.nodes:
        for j in g1.nodes:
            if i != j and (i, j) not in g1.edges and (j, i) not in g1.edges:
                t = r.uniform(0, 1)
                if t < density:
                    g1.add_edge(i, j)
                    for attr in edge_attrs:
                        g1.edges[i, j][str(attr)] = r.choice(edge_attrs[attr])

    # connect the nodes for g2
    while len(connected_nodes2) < num_nodes:
        i = r.sample(connected_nodes2, 1)[0]
        choices = [j for j in list(g2.nodes) if j not in connected_nodes2]
        if not choices:
            continue
        c = r.choice(choices)
        g2.add_edge(i, c)
        for attr in edge_attrs:
            g2.edges[i, c][str(attr)] = r.choice(edge_attrs[attr])
        connected_nodes2.add(c)

    # add edges using density for g2
    for i in g2.nodes:
        for j in g2.nodes:
            if i != j and (i, j) not in g2.edges and (j, i) not in g2.edges:
                t = r.uniform(0, 1)
                if t < density:
                    g2.add_edge(i, j)
                    for attr in edge_attrs:
                        g2.edges[i, j][str(attr)] = r.choice(edge_attrs[attr])

    # add the new graphs to the current aggregated graph
    current_G1.add_nodes_from(g1.nodes.data())
    current_G1.add_edges_from(g1.edges.data())
    current_G2.add_nodes_from(g2.nodes.data())
    current_G2.add_edges_from(g2.edges.data())

    return g1, g2, current_G1, current_G2


def generate_pair_of_matching_graphs_for_structure(current_G1, current_G2, num_nodes, node_attrs, edge_attrs, ws=0.5,
                                                   density=0.5):
    """Inputs: current_G1, current_G2: current G1 and G2 graphs, the new graph is added to the current ones
               num_nodes - number of nodes in a graph
               node_attrs - a dict of node attributes as stringsand their domains,
                            the exact values of attributes are randomly generated
               edge_attrs - a dict of edge attributes as strings and their domains,
                            the exact values of attributes are randomly generated
               ws - a parameter in [0,1] determining the significance in structure similarity in generating the pairs, 1 if only node
                    attributes are considered
               density - a parameter in [0,1] decides how dense the graph should be, on the premise that the graph is connected,
                         1 is fully connected and 0 is a spanning tree. A number between is the probability that an edge is added
                         between two nodes. The spanning tree is randomly generated.
       Return: one pair of matching graphs
       Strategy: If focusing on structure, generate one graph first, then generate a similar structure, then add attributes
                to the nodes"""

    g1 = nx.Graph()
    g2 = nx.Graph()

    if current_G1.nodes:
        n1 = r.sample(current_G1.nodes.data(),
                      1)  # select a point of overlapping for the current graph and the new pair
        g1.add_nodes_from(n1)

    ################################# 2. When focusing on the structure
    # generate random nodes
    if len(g1.nodes) > 0:  # no. of new nodes to be generated
        ni = num_nodes - 1
    else:
        ni = num_nodes
    # generate random nodes
    for i in range(len(current_G1.nodes), len(current_G1.nodes) + ni):
        g1.add_node(i)
        for attr in node_attrs:
            g1.nodes[i][str(attr)] = r.choice(node_attrs[attr])

    connected_nodes = {list(g1.nodes)[0]}  # record currently connected nodes
    # connect the nodes for g1
    while len(connected_nodes) < num_nodes:
        i = r.sample(connected_nodes, 1)[0]
        choices = [j for j in list(g1.nodes) if j not in connected_nodes]
        if not choices:
            continue
        c = r.choice(choices)
        g1.add_edge(i, c)
        for attr in edge_attrs:
            g1.edges[i, c][str(attr)] = r.choice(edge_attrs[attr])
        connected_nodes.add(c)

    # create a similar structure for g2 from g1
    g2.add_edges_from(g1.edges.data())

    # add edges using density for g1
    for i in g1.nodes:
        for j in g1.nodes:
            if i != j and (i, j) not in g1.edges and (j, i) not in g1.edges:
                t = r.uniform(0, 1)
                if t < density:
                    g1.add_edge(i, j)
                    for attr in edge_attrs:
                        g1.edges[i, j][str(attr)] = r.choice(edge_attrs[attr])

    # create a similar structure for the additional edges for g2 from g1
    for e in g1.edges.data():
        if (e[0], e[1]) not in g2.edges.data():
            if r.uniform(0, 1) < ws:
                g2.add_edges_from([e])

    # generate random nodes for g2
    for i in g2.nodes:
        for attr in node_attrs:
            g2.nodes[i][str(attr)] = r.choice(node_attrs[attr])

    # add the new graphs to the current aggregated graph
    current_G1.add_nodes_from(g1.nodes.data())
    current_G1.add_edges_from(g1.edges.data())
    current_G2.add_nodes_from(g2.nodes.data())
    current_G2.add_edges_from(g2.edges.data())

    return g1, g2, current_G1, current_G2


def generate_n_pairs_of_matching_graphs(n, num_nodes, node_attrs, edge_attrs, wn=0.5, ws=0.5, density=0.5):
    """Inputs: n - number of pairs of graphs to be generated
               num_nodes - number of nodes in a graph
               node_attrs - a dict of node attributes as stringsand their domains,
                            the exact values of attributes are randomly generated
               edge_attrs - a dict of edge attributes as strings and their domains,
                            the exact values of attributes are randomly generated
               wn - a parameter in [0,1] determining the significance in node similarity in generating the pairs, 1 if only node
                    attributes are considered(i.e. all nodes are the same, otherwise, each node has wn probability to change its
                    attributes)
               ws - a parameter in [0,1] determining the significance in structure similarity in generating the pairs, 1 if only node
                    attributes are considered
               density - a parameter in [0,1] decides how dense the graph should be, on the premise that the graph is connected,
                         1 is fully connected and 0 is a spanning tree. A number between is the probability that an edge is added
                         between two nodes. The spanning tree is randomly generated.
       Return: G1 and G2, the aggregated graphs"""
    G1 = nx.Graph()
    G2 = nx.Graph()
    subgraphs_G1 = []  # a list to store all the constituent subgraphs in G1
    subgraphs_G2 = []  # a list to store all the constituent subgraphs in G2

    for i in range(n):
        g1, g2, G1, G2 = generate_pair_of_matching_graphs_for_nodes(G1, G2, num_nodes, node_attrs, edge_attrs, wn,
                                                                    density)
        subgraphs_G1.append(g1)
        subgraphs_G2.append(g2)
        print(i + 1, " pairs generated")

    return G1, G2, subgraphs_G1, subgraphs_G2